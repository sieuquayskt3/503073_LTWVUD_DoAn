// -------------------Cấu hình express
let express = require("express"); // tạo express
let app = express();
app.use(express.static("public"));
app.set('view engine', 'ejs');
app.set('views', './views');

app.get("/", (req, res)=>{
    res.render("webchat");
});

// gắn express vào cổng 1234
let server = require("http").Server(app); 
server.listen(1234, ()=>{
    console.log("connecting port 1234...");
});

// -------------------Cấu hình socket.io

let usersName = [];
let usersID = []; // dùng xác định vị trí cần xóa khi disconnect

let io = require("socket.io")(server);

io.on("connection", (socket)=>{
    console.log("user connected! id: " + socket.id);

    // gửi users list đang online và đã chat
    io.emit("usersName", usersName);

    //- server lắng nghe khi có người gửi message
    socket.on("message", (msg)=>{
        //- server gửi nội dung cho toàn bộ client
        io.emit("message2", msg);
    });

    // cập nhật users list khi có "user name" mới
    socket.on("userName", (msg2)=>{
        if (usersName.indexOf(msg2) != -1){
            // user name đã tồn tại
        } else {
            // user name chưa tồn tại
            usersName.push(msg2);
            usersID.push(socket.id);
            io.emit("usersName", usersName);
        }
    });

    //-
    socket.on("disconnect", ()=>{
        // cập nhật users list
        let index = usersID.indexOf(socket.id);
        usersID.splice(index, 1);

        let user = usersName.splice(index, 1);
        io.emit("usersName", usersName);

        console.log(socket.id + " disconnected!");
    });
});




